Recoil reducer with klar.gg's leaked rainbow six siege anti cheat bypass. Be sure to use it cause R6 now detects weird mouse movements. 

Happy Scripting!